"""
Command line interface for the Meme Lineage Agent.

This script allows you to invoke the lineage detection logic from the
terminal.  Given a token mint address it calls into the `detect_lineage`
function and prints a simple summary of the results.
"""

import argparse

from lineage_agent.lineage_detector import detect_lineage


def main() -> None:
    """Entry point for the command‑line interface."""
    parser = argparse.ArgumentParser(
        description="Detect memecoin lineage by mint address"
    )
    parser.add_argument(
        "--mint",
        required=True,
        help="Mint address of the token to analyse",
    )
    args = parser.parse_args()

    # Perform lineage detection
    result = detect_lineage(args.mint)

    # Print a user-friendly summary
    print("Mint:", result.get("mint"))
    print("Root:", result.get("root"))
    print("Confidence:", result.get("confidence"))
    print("Derivatives:", result.get("derivatives"))


if __name__ == "__main__":
    main()