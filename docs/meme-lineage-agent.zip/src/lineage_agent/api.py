"""
REST API for the Meme Lineage Agent using FastAPI.

This module defines a simple API for retrieving the lineage of a given
token.  It uses FastAPI to expose an HTTP endpoint at `/lineage` that
accepts a mint address as a query parameter and returns JSON with
lineage details.
"""

from fastapi import FastAPI, HTTPException

from .lineage_detector import detect_lineage


app = FastAPI(title="Meme Lineage Agent API")


@app.get("/lineage")
def get_lineage(mint: str) -> dict:
    """API endpoint to fetch the lineage of a token.

    Parameters
    ----------
    mint : str
        The mint address of the token to analyse.

    Returns
    -------
    dict
        A dictionary containing the mint, root, confidence and derivatives.
    """
    if not mint:
        raise HTTPException(status_code=400, detail="Mint address required")
    result = detect_lineage(mint)
    return result
