# Meme Lineage Agent

This repository contains the code and documentation for a **Meme Lineage Agent**,
an agentic tool built for the Solana memecoin ecosystem.  The agent helps
detect and manage the lineage of memecoins by identifying the original token
(the **root**) and its derivatives (forks, clones and imposters).  In a space
where dozens of tokens share the same name or image, this tool aims to
provide clarity and reduce confusion for traders, communities and
aggregators.

## Problem Statement

Memecoins on Solana often proliferate through imitations: the same mascot,
emoji or catchy name can spawn multiple tokens.  Without a clear way to
distinguish the **real** token from opportunistic clones, new entrants
accidentally buy the wrong token, communities fragment, and scammers thrive.
The lack of a trusted “identity” layer for fungible tokens leads to
mismatched metadata, cloned logos and reused tickers.  Jupiter’s
“strict token list” mechanism was an early response to this issue【996237790117841†screenshot】,
but there is still no unified view of a token’s family tree.

The Meme Lineage Agent addresses this by grouping tokens into families
(`root` plus all `derivatives`) and exposing those relationships via
simple interfaces.

## Key Features

- **Lineage Detection** – Uses token metadata (name, symbol, metadata URI),
  image similarity, deployer addresses and creation timestamps to determine
  which token is the root and which are derivatives.
- **Family Tree Generation** – Builds a graph representing the relationship
  among tokens, with confidence scores for each link.
- **Interactive Queries** – Provides a Telegram bot and a web API to query
  a token and receive lineage information, returning concise lineage cards
  that are easy to share.
- **Alerting** – Supports watchlists and notifications when new clones
  appear or suspicious derivatives are created.
- **Evidence Pack** – Gathers evidence supporting each lineage decision
  (metadata comparisons, image perceptual hashes, creation sequence,
  social links, etc.) so that decisions are transparent and debatable.

## Repository Structure

```
meme-lineage-agent/
├── README.md            # Project overview and setup instructions (this file)
├── requirements.txt     # Python dependencies
├── src/
│   ├── main.py          # CLI entrypoint for lineage detection
│   ├── config.py        # Configuration settings (API keys, thresholds)
│   └── lineage_agent/
│       ├── __init__.py  # Package marker and exports
│       ├── lineage_detector.py  # Core logic for detecting lineage
│       ├── telegram_bot.py      # (Optional) Telegram bot implementation
│       └── api.py               # (Optional) REST API implementation
└── tests/               # (Optional) unit tests and examples
```

### `src/main.py`

This script is the CLI entrypoint.  When run with a token mint address, it
invokes the lineage detector and prints a summary of the family tree.  It
demonstrates how the library can be used from the command line and
provides a starting point for building more complex tools.

### `src/lineage_agent/lineage_detector.py`

The heart of the project.  This module contains functions to fetch token
metadata from on‑chain sources (e.g. Metaplex metadata), off‑chain APIs
(DexScreener, Pump.fun), compute similarity metrics (perceptual hashes,
fuzzy string matching, deployer analysis), build the family tree, select
the most probable root and assign confidence scores.  The current
implementation is a stub that returns a dummy lineage; you should extend
it with real logic.

### `src/lineage_agent/telegram_bot.py` (optional)

Provides a Telegram bot interface that listens for commands like
`/lineage <TOKEN_MINT>` in a chat.  The bot sends a lineage card summarizing
the root candidate, clones, and risk flags.  To use the bot you must
configure your Telegram bot token in `config.py`.

### `src/lineage_agent/api.py` (optional)

Exposes a simple REST API using FastAPI.  For example, calling
`/lineage?mint=<TOKEN_MINT>` returns JSON containing the root, clones and
evidence.  This is useful for wallets, aggregators or dashboards that
integrate the lineage service.

## Installation

This project requires **Python 3.11** or newer.  We recommend using a
virtual environment:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Usage

### Command Line

Detect the lineage of a token given its mint address:

```bash
python src/main.py --mint <TOKEN_MINT>
```

This will print a summary including:

- **Mint** – the input address.
- **Root** – candidate root mint.
- **Confidence** – score from 0 to 1 indicating how confident the model
  is that the selected root is genuine.
- **Derivatives** – list of suspected clones with brief notes.

### Telegram Bot

To run the bot you need to set your Telegram bot token in `config.py`.
Then execute:

```bash
python src/lineage_agent/telegram_bot.py
```

In Telegram, you can type `/lineage <TOKEN_MINT>` or send a mint address
directly to the bot; it will respond with a lineage card and buttons to
view proofs, report a clone or subscribe to alerts.

### Web API

Run the API server with:

```bash
python src/lineage_agent/api.py
```

By default this starts a FastAPI app on `http://localhost:8000`.  The main
endpoint is `/lineage`, e.g.:

```
GET /lineage?mint=4Nd1mRLqD7GVZKxLKJUxg8LjvfsD9sV4PKgEaJu2Fbty
```

which returns JSON with the root and clones.  You can integrate this
endpoint into your own applications or dashboards.

## Development Roadmap

1. **Data Sources** – Integrate on‑chain metadata via RPC, Metaplex,
   DexScreener’s token profiles, Pump.fun lifecycle data and other
   sources.  This will require asynchronous HTTP requests and caching.
2. **Similarity Metrics** – Implement algorithms for image perceptual
   hashing (e.g. `pHash`), fuzzy string matching (Levenshtein distance),
   and heuristics for shared deployer/funder addresses.
3. **Scoring Model** – Combine multiple signals into a confidence score
   using a weighted model.  Tune thresholds to minimize false
   positives/negatives.
4. **User Interfaces** – Expand the bot features (watchlists, clone
   reporting, fairness scoring) and build a web dashboard for exploring
   family trees visually.
5. **Analytics & Metrics** – Track adoption metrics (queries per day,
   watchlist count), false positive rates, and user feedback to guide
   future improvements.

## Contributing

Contributions are welcome!  Feel free to open an issue or pull request
with feature suggestions or bug reports.  Please ensure that any code
submitted is well‑documented and includes appropriate tests in the
`tests/` directory.
